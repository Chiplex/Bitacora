;
((d,c,$)=>{
    c("hello adimin Wordpress")
})(document, console.log, jQuery.noConflict());