;
((d,c,$)=>{
    c("hello Login Wordpress")
})(document, console.log, jQuery.noConflict());