;
$ = jQuery.noConflict();