<aside class="Comments Other">
    <ol><?php wp_list_comments() ?></ol>    
    <?php comment_form() ?>
</aside>