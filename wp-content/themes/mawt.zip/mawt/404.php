<?php 
get_header();
echo '<p class="Error404">no existe la pagina</p>';
get_sidebar();
get_footer();
?>